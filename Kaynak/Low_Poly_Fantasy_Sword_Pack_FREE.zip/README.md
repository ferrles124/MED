# Low Poly Fantasy Sword Pack

## Free game-ready models

This free package contains 10 distinct low-poly fantasy swords, plus combined all-swords files for convenient preview or import.

Included formats: FBX and GLB.

Asset categories: classic adventure swords, a greatsword, a curved falchion, a katana-inspired blade, and elemental, cursed, and holy fantasy weapons.

The free download is the complete game-ready model pack. The original Blender source project is not included here; it is available separately for $1.

No colliders are included. Import FBX in Unity or Unreal Engine, or GLB in Godot, Blender, WebGL, Three.js, Babylon.js, and other compatible software.

See LICENSE.txt for the Cenji Asset License. Personal and commercial use is allowed; raw asset redistribution and resale are not.
